"""Shared geometry, route replay and CSV export for continuous schedules."""
import csv
import heapq
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.spatial import ConvexHull

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "综合" / "代码"))
from check_bounds import RECTANGLES, RADIUS


STARTS = np.array([(15, 14), (88, 10), (14, 86), (88, 68), (50, 93)], dtype=float)
ALERTS = [(30, 40, 45), (150, 45, 35), (285, 38, 55)]
TARGETS = np.array([
    (50 + r * math.cos(math.radians(a)), 50 + r * math.sin(math.radians(a)), h)
    for a, r, h in ALERTS
])
BUILDINGS = np.column_stack((RECTANGLES, [20, 28, 12, 24, 32]))
SPEED, TURN, OBSERVE = 3.0, 30.0, 5.0
EDGE = 100 - RADIUS
PAD = RADIUS + 0.001
OMEGA = math.radians(TURN)
OUTPUT = ROOT / "第二问" / "文档"


def shadow_polygons():
    shadows = []
    for x, y, h in TARGETS:
        target = np.array([x, y])
        polygons = []
        for left, right, bottom, top, roof in BUILDINGS:
            corners = np.array([(a, b) for a in (left, right) for b in (bottom, top)])
            scale = (h - 2) / (h - roof)
            far = target + scale * (corners - target)
            polygons.append(ConvexHull(np.vstack((corners, far))).equations)
        shadows.append(polygons)
    return shadows


def hit(start, end, rectangle, last=1.0):
    """Closed segment/slab intersection, restricted to the parameter [0, last]."""
    start, end = np.asarray(start), np.asarray(end)
    shape = np.broadcast_shapes(start.shape[:-1], end.shape[:-1])
    low, high = np.zeros(shape), np.full(shape, last)
    for axis, (left, right) in enumerate(np.reshape(rectangle, (2, 2))):
        origin = start[..., axis]
        direction = end[..., axis] - origin
        moving = direction != 0
        divisor = np.where(moving, direction, 1)
        a, b = (left - origin) / divisor, (right - origin) / divisor
        low = np.maximum(low, np.where(moving, np.minimum(a, b), -np.inf))
        high = np.minimum(high, np.where(moving, np.maximum(a, b), np.inf))
        high = np.where(~moving & ((origin < left) | (origin > right)), -np.inf, high)
    return low <= high


def road(start, end, padding=PAD):
    clear = True
    for left, right, bottom, top in RECTANGLES:
        # Open rectangle slightly larger than the exact rounded obstacle.
        pad = padding - 1e-7
        clear = clear & ~hit(start, end, (left-pad, right+pad, bottom-pad, top+pad))
    return clear


def angles(points, task):
    x, y, h = TARGETS[task]
    dx, dy = x - points[..., 0], y - points[..., 1]
    yaw = np.degrees(np.arctan2(dy, dx))
    pitch = np.degrees(np.arctan2(h - 2, np.hypot(dx, dy)))
    return yaw, pitch


def turn_time(points, task):
    yaw, pitch = angles(points, task)
    return np.maximum(np.abs(yaw), pitch) / TURN


def visible(points, task):
    target = TARGETS[task]
    clear = angles(points, task)[1] <= 80
    for *rectangle, roof in BUILDINGS:
        clear &= ~hit(points, target[:2], rectangle, (roof - 2) / (target[2] - 2))
    return clear


class Roads:
    """Finite waypoint graph used by both strategies to price and recover paths."""

    def __init__(self, padding=PAD):
        self.padding = padding
        self.corners = np.array([
            (x, y) for left, right, bottom, top in RECTANGLES
            for x in (left - padding, right + padding) for y in (bottom - padding, top + padding)
        ])
        self.edges = [
            [(j, float(np.linalg.norm(p - q))) for j, q in enumerate(self.corners)
             if i != j and road(p, q, self.padding)]
            for i, p in enumerate(self.corners)
        ]

    def paths(self, origin, points):
        direct = road(origin, points, self.padding)
        best = np.where(direct, np.linalg.norm(points - origin, axis=1), np.inf)
        via = np.full(len(points), -1, dtype=int)
        dist = np.where(road(origin, self.corners, self.padding),
                        np.linalg.norm(self.corners - origin, axis=1), np.inf)
        previous = [-1] * len(dist)
        heap = [(d, i) for i, d in enumerate(dist) if np.isfinite(d)]
        heapq.heapify(heap)
        while heap:
            d, i = heapq.heappop(heap)
            if d != dist[i]:
                continue
            for j, length in self.edges[i]:
                if d + length < dist[j]:
                    dist[j], previous[j] = d + length, i
                    heapq.heappush(heap, (dist[j], j))
        for i, corner in enumerate(self.corners):
            trial = dist[i] + np.linalg.norm(points - corner, axis=1)
            better = (trial < best - 1e-10) & road(corner, points, self.padding)
            best[better], via[better] = trial[better], i
        return best, via, previous

    def route(self, origin, station):
        _, via, previous = self.paths(origin, np.array([station]))
        interior = []
        i = via[0]
        while i >= 0:
            interior.append(self.corners[i])
            i = previous[i]
        return np.array([origin, *reversed(interior), station])


def pair_compatible(a, b, task):
    u, v = a - TARGETS[task, :2], b - TARGETS[task, :2]
    return (np.linalg.norm(a - b, axis=-1) >= 2 * RADIUS) & (
        abs(u[..., 0] * v[..., 1] - u[..., 1] * v[..., 0]) > 1e-7
    )


@dataclass
class Leg:
    car: int
    task: int
    route: np.ndarray
    depart: float
    arrive: float
    ready: float
    start: float
    end: float
    reset: float


def replay(roads, plan):
    position, available = STARTS.copy(), np.zeros(5)
    result = []
    for task, assignment in plan:
        pending = []
        for k, station in assignment:
            route = roads.route(position[k], station)
            length = np.linalg.norm(np.diff(route, axis=0), axis=1).sum()
            turn = turn_time(station, task)
            arrive = available[k] + length / SPEED
            pending.append((k, route, available[k], arrive, turn))
        start = max(arrive + turn for _, _, _, arrive, turn in pending)
        for k, route, depart, arrive, turn in pending:
            reset = start + OBSERVE + turn
            result.append(Leg(k, task, route, depart, arrive, arrive + turn,
                              start, start + OBSERVE, reset))
            position[k], available[k] = route[-1], reset
    return result


def objective(legs):
    return max(leg.start for leg in legs)


def export(solutions, path=OUTPUT / "第二问第（2）题逐车时间轴.csv"):
    rows = []
    for name, legs in solutions.items():
        for leg in sorted(legs, key=lambda leg: (leg.car, leg.depart)):
            station = leg.route[-1]
            yaw, pitch = angles(station, leg.task)
            rows.append({
                "方案": name, "车辆": f"V{leg.car + 1}", "告警": f"T{leg.task + 1}",
                "路径坐标_m": json.dumps(leg.route.tolist(), separators=(",", ":")),
                "行驶_m": f"{(leg.arrive - leg.depart) * SPEED:.9f}",
                "方位角_deg": f"{yaw:.9f}", "俯仰角_deg": f"{pitch:.9f}",
                "出发_s": f"{leg.depart:.9f}", "到站_转动开始_s": f"{leg.arrive:.9f}",
                "指向完成_s": f"{leg.ready:.9f}", "观测开始_s": f"{leg.start:.9f}",
                "观测结束_复位开始_s": f"{leg.end:.9f}", "复位完成_s": f"{leg.reset:.9f}",
            })
    with path.open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    return path
